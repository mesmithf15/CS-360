package com.zybooks.inventoryappmarcussmith;

import android.app.Activity;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CustomItemsListActivity extends BaseAdapter {

    private final Activity context;
    private PopupWindow popwindow;
    ArrayList<Item> items;
    SqlItemDatabase db;

    public CustomItemsListActivity(Activity context, ArrayList<Item> items, SqlItemDatabase db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }

    public static class ViewHolder {
        TextView itemId;
        TextView userEmail;
        TextView itemDesc;
        TextView itemQty;
        TextView itemUnit;
        ImageButton editButton;
        ImageButton deleteButton;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;

        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.activity_custom_items_list, null, true);

            vh.editButton = row.findViewById(R.id.editButton);
            vh.itemId = row.findViewById(R.id.textViewItemId);
            vh.userEmail = row.findViewById(R.id.textViewUserEmail);
            vh.itemDesc = row.findViewById(R.id.textViewItemDesc);
            vh.itemQty = row.findViewById(R.id.textViewItemQty);
            vh.itemUnit = row.findViewById(R.id.textViewItemUnit);
            vh.deleteButton = row.findViewById(R.id.deleteButton);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        vh.itemId.setText(String.valueOf(items.get(position).getId()));
        vh.userEmail.setText(items.get(position).getUserEmail());
        vh.itemDesc.setText(items.get(position).getDesc());
        vh.itemQty.setText(items.get(position).getQty());
        vh.itemUnit.setText(items.get(position).getUnit());

        final int positionPopup = position;

        vh.editButton.setOnClickListener(view -> editPopup(positionPopup));

        vh.deleteButton.setOnClickListener(view -> {
            //Integer index = (Integer) view.getTag();
            db.deleteItem(items.get(positionPopup));

            //items.remove(index.intValue());
            items = (ArrayList<Item>) db.getAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();

            int itemsCount = db.getItemsCount();
            TextView TotalItems = context.findViewById(R.id.deleteButton);
            TotalItems.setText(String.valueOf(itemsCount));
        });

        return  row;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public int getCount() {
        return items.size();
    }

    public void editPopup(final int positionPopup) {
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_custom_items_list, context.findViewById(R.id.popup_element));

        popwindow = new PopupWindow(layout, 800, 1000, true);
        popwindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        final EditText editItemDesc = layout.findViewById(R.id.editTextItemDescriptionPopup);
        final EditText editItemQty = layout.findViewById(R.id.editTextItemQtyPopup);
        final EditText editItemUnit = layout.findViewById(R.id.editTextItemUnitPopup);

        editItemDesc.setText(items.get(positionPopup).getDesc());
        editItemQty.setText(items.get(positionPopup).getQty());
        editItemUnit.setText(items.get(positionPopup).getUnit());

        Button save = layout.findViewById(R.id.editSaveButton);
        Button cancel = layout.findViewById(R.id.editCancelButton);

        save.setOnClickListener(view -> {
            String itemDesc = editItemDesc.getText().toString();
            String itemQty = editItemQty.getText().toString();
            String itemUnit = editItemUnit.getText().toString();

            Item item = items.get(positionPopup);
            item.setDesc(itemDesc);
            item.setQty(itemQty);
            item.setUnit(itemUnit);

            db.updateItem(item);
            items = (ArrayList<Item>) db.getAllItems();
            notifyDataSetChanged();

            Toast.makeText(context, "Item Updated", Toast.LENGTH_SHORT).show();

            popwindow.dismiss();
        });

        cancel.setOnClickListener(view -> {
            Toast.makeText(context, "Action Canceled", Toast.LENGTH_SHORT).show();
            popwindow.dismiss();
        });
    }

}
